#include "Parameter.h"

Parameter::Parameter(const DWORD parameter) noexcept
    : parameter(parameter) {}
