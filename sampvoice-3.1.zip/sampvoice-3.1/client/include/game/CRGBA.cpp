/*
    Plugin-SDK (Grand Theft Auto San Andreas) source file
    Authors: GTA Community. See more here
    https://github.com/DK22Pac/plugin-sdk
    Do not delete this comment block. Respect others' work!
*/
#include "CRGBA.h"

CRGBA::CRGBA(unsigned char r, unsigned char g, unsigned char b, unsigned char a)
{
	((void (__thiscall *)(CRGBA *, unsigned char, unsigned char, unsigned char, unsigned char))0x7170C0)(this, r, g, b, a);
}

CRGBA::CRGBA()
{

}