/*
    Plugin-SDK (Grand Theft Auto San Andreas) source file
    Authors: GTA Community. See more here
    https://github.com/DK22Pac/plugin-sdk
    Do not delete this comment block. Respect others' work!
*/
#include "CCheckpoint.h"

// Converted from thiscall void CCheckpoint::Render(void) 0x725C00
void CCheckpoint::Render() {
    plugin::CallMethod<0x725C00, CCheckpoint *>(this);
}