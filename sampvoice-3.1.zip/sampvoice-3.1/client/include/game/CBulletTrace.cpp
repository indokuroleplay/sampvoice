/*
    Plugin-SDK (Grand Theft Auto San Andreas) source file
    Authors: GTA Community. See more here
    https://github.com/DK22Pac/plugin-sdk
    Do not delete this comment block. Respect others' work!
*/
#include "CBulletTrace.h"

// Converted from thiscall void CBulletTrace::Update(void) 0x721D70
void CBulletTrace::Update() {
    plugin::CallMethod<0x721D70, CBulletTrace *>(this);
}